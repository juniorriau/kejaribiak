<?php

/* 
 * Copyright (C) 2015 Junior Riau <juniorriau18@gmail.com>.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301  USA
 */

return array(
    'db' => array(
        'host' => 'localhost', // 127.0.0.1
        'port' => '3306', // default mysql
        'username' => 'bpmp_bpmp',
        'password' => '-*&+y=BW5!*C',
        'dbname' => 'bpmpbangdes',
    ),
    'timezone' => 'Asia/Jakarta',
    'salt' => 'AB87@#5edV!3s)98s^7_9*6HNM%$))$%Has34bk98s*9)&S$@sda',
    'base_include' => array(
        'views' => 'views',
        'controllers' => 'controllers',
    ),
    'slugcat'=>'category',
    'slugpost'=>'posts',
    'slugpage'=>'pages',
    
);
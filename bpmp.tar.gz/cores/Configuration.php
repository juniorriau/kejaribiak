<?php

/* 
 * Copyright (C) 2015 Junior Riau <juniorriau18@gmail.com>.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301  USA
 */

class Configuration{
    /**
     * @var array variable tempat penyimpanan item-item konfigurasi
     * 
     */
    private static $config_items = array();
    
    /**
     * Memuat file konfigurasi berdasarkan path yang diberikan
     * @param string $config_path lokasi ke file konfigurasi
     */
    public static function load($config_path)
    {
        if(file_exists($config_path)){
            self::$config_items = include $config_path;
            return true;
        }else{
            return false;
        }
    }
    
    /**
     * Menyimpan satu item konfigurasi
     * @param string $key kunci item yang akan disimpan
     * @param string $value nilai item yang akan disimpan
     */
    public static function set($key, $value)
    {
        self::$config_items[$key] = $value;
    }
    
    /**
     * Mendapatkan satu item konfigurasi
     * @param string $key kunci item yang dicari
     * @param mixed $default nilai default jika kunci yang dicari tidak ditemukan
     * @return mixed tergantung isi dari kunci yang dicari
     */
    public static function get($key, $default = null)
    {
        if(isset(self::$config_items[$key])){
            return self::$config_items[$key];
        }
        return $default;
    }
    
    /**
     * Memeriksa apakah kunci tertentu ada di konfigurasi
     * @param string $key kunci item yang dicari
     * @return boolean
     */
    public static function has($key)
    {
        if(isset(self::$config_items[$key])){
            return true;
        }
        return false;
    }
}
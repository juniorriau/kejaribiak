<?php

/* 
 * Copyright (C) 2015 Junior Riau <juniorriau18@gmail.com>.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301  USA
 */
class Uploader{
    private $fileType;
    private $image;
    public $message=FALSE;
    private $extension;
    private $allowExt=array('doc','docx','jpg','jpeg','png','rar','zip','pdf');
    
    private function getInfo($file){
        $temp=getimagesize($file);
        $this->fileType=$temp[2];
        if( $this->fileType == IMAGETYPE_JPEG ){
            $this->image = imagecreatefromjpeg($file);
        }
        elseif( $this->fileType == IMAGETYPE_GIF ){
            $this->image = imagecreatefromgif($file);
        }
        elseif( $this->fileType == IMAGETYPE_PNG ){
            $this->image = imagecreatefrompng($file);
        }
        
    }
    private function checkExt($file){
        $this->getInfo($file);
        $stat=FALSE;
        if( $this->fileType == IMAGETYPE_JPEG ){
            $stat=TRUE;
            $this->extension=".jpg";
        }
        elseif( $this->fileType == IMAGETYPE_GIF ){
            $stat=TRUE;
            $this->extension=".gif";
        }
        elseif( $this->fileType == IMAGETYPE_PNG ){
            $stat=TRUE;
            $this->extension=".jpg";
        }
        return $stat;
    }
    private function checkMime($file){
        $stat=FALSE;
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $file);
        if($mime=="application/pdf"){
            $stat=TRUE;
        }elseif($mime=="application/msword"){
            $stat=TRUE;
        }elseif($mime=="application/x-zip"){
            $stat=TRUE;
        }elseif($mime=="application/msword"){
            $stat=TRUE;
        }elseif($mime=="application/x-rar"){
            $stat=TRUE;
        }elseif($mime=="application/zip"){
            $stat=TRUE;
        }elseif($mime=="application/rar"){
            $stat=TRUE;
        }
        return $stat;
    }
    private function saveI($file,$path){
        $this->getInfo($file);
        if( $this->fileType == IMAGETYPE_JPEG ){
            if(imagejpeg($this->image,$path)){
                $this->message=TRUE;
            }
            else{
                $this->message=FALSE;
            }
        }
        elseif( $this->fileType == IMAGETYPE_GIF ){
            if(imagegif($this->image,$path)){
                $this->message=TRUE;
            }
            else{
                $this->message=FALSE;
            }
        }
        elseif( $this->fileType == IMAGETYPE_PNG ){
            if(imagepng($this->image,$path)){
                $this->message=TRUE;
            }
            else{
                $this->message=FALSE;
            }
        }
        return $this->message;
    }
    private function saveF($file,$path){
        move_uploaded_file($file, $path);
    }
    public function saveImage($file,$path){
        $up=$this->checkExt($file['tmp_name']);
        if($up===FALSE){
            return "Not allowed file!";
        }
        else{
                $up=$this->saveI($file['tmp_name'],$path.$file['name']);
                return $up;
        }
    }
    public function reArray($file) {

        $file_ary = array();
        $file_count = count($file['name']);
        $file_keys = array_keys($file);

        for ($i=0; $i<$file_count; $i++) {
            foreach ($file_keys as $key) {
                $file_ary[$i][$key] = $file[$key][$i];
            }
        }

        return $file_ary;
    }
    public function saveFile($file,$path){
        $up=$this->checkMime($file['tmp_name']);
        if($up===FALSE){
            return "Not allowed file!";
        }
        else{
                $up=$this->saveF($file['tmp_name'],$path.$file["name"]);
                return $up;
        }
    }
}
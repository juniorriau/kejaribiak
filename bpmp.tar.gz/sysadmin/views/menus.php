<?php
echo "<div class='content-wrapper'>";
switch ($uri[1]) {
    case "all":
        $menu=  DBDriver::all("SELECT `id`, `name`, `publish`, `isparent` FROM `menu` ORDER by `id` Asc");
        ?>           
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <h1>
                Manage Menu
              </h1>
              <ol class="breadcrumb">
                <li><a href="<?php echo Request::base_url();?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo Request::base_url()."/".$uri[0]."/all";?>">Category</a></li>
                <li class="active">View</li>
              </ol>
            </section>

            <!-- Main content -->
            <section class="content">
              <div class="row">
                <div class="col-xs-12">

                  <div class="box">
                    <div class="box-body">
                      <table id="data" class="table table-bordered table-striped">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>Menu Name</th>
                            <th>Published</th>
                            <th>Main Menu</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $row = 1;
                            foreach($menu as $m): ?>
                          <tr>
                            <td><?php echo $row;?></td>
                            <td><?php echo $m->name;?></td>
                            <td><?php echo $m->publish ? 'Yes' : 'No'; ?></td>
                            <td><?php echo $m->isparent;?></td>
                            <td>
                                <a class="btn btn-primary btn-sm" title="Edit" href="<?php echo Request::base_url().'/'.$uri[0]."/update/".$m->id;?>"><span class="glyphicon glyphicon-pencil"></a>
                                <a class="btn btn-danger btn-sm" title="Delete" href="<?php echo Request::base_url().'/'.$uri[0]."/delete/".$m->id;?>"><span class="glyphicon glyphicon-trash"></a>
                            </td>
                          </tr>
                          <?php $row++; endforeach; ?>
                        </tbody>
                      </table>
                    </div><!-- /.box-body -->
                  </div><!-- /.box -->
                </div><!-- /.col -->
              </div><!-- /.row -->
            </section><!-- /.content -->
        
        <?php
        break;
        
    case "add":
        $menu=  DBDriver::all("SELECT `id`, `name`, `publish` FROM `menu` ORDER by `id` Asc");
        ?>
            <section class="content-header">
                <h1>
                Manage Menu
              </h1>
              <ol class="breadcrumb">
                <li><a href="<?php echo Request::base_url();?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo Request::base_url()."/".$uri[0]."/all";?>">Menu</a></li>
                <li class="active">Add</li>
              </ol>
            </section>
            <section class="content">
                <div class='row'>
                    <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                  <div class="box-header with-border">
                    <h3 class="box-title">Add Menu</h3>
                  </div><!-- /.box-header -->
                  <!-- form start -->
                  <form role="form" method="post" action="<?php echo Request::base_url()."/".$uri[0]."/".$uri[1];?>">
                    <div class="box-body">
                      <div class="form-group">                        
                        <label for="name">Menu Name</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Enter Menu" required="required">
                      </div>
                      <div class="form-group">
                        <label for="publish">Publish</label>
                        <select class="form-control" id="publish" name="publish">
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="publish">Parent</label>
                        <select class="form-control" id="parent" name="parent">
                            <?php 
                            if(empty($menu)){ ?>
                                <option value="">None</option>
                            <?php
                            
                            }else{
                                echo '<option value="">None</option>';
                                foreach($menu as $m): ?>
                                <option value="<?php echo $m->id;?>" ><?php echo $m->name; ?></option>
                            <?php endforeach; 
                            }?>
                        </select>
                      </div>
                    </div><!-- /.box-body -->

                    <div class="box-footer">
                      <button type="submit" class="btn btn-primary">Submit</button>
                      <button type="reset" class="btn btn-warning">Reset</button>
                    </div>
                  </form>
                </div><!-- /.box -->

              </div><!--/.col (left) -->
                </div>
            </section>
            <?php
        break;
    
    case "update":
        $menu=DBDriver::row("SELECT `id`, `name`, `publish`, `isparent` FROM `menu` WHERE id=:id", array(':id' => $uri[2]));
        $menulist=DBDriver::all("SELECT `id`, `name`, `publish` FROM `menu` WHERE publish=1 and id<>:id and isparent<>:isparent",array(':id' => $uri[2], ':isparent' => $uri[2]));
        ?><section class="content-header">
            <h1>
                Manage Menu
              </h1>
              <ol class="breadcrumb">
                <li><a href="<?php echo Request::base_url();?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo Request::base_url()."/".$uri[0]."/all";?>">Category</a></li>
                <li class="active">Update</li>
              </ol>
            </section>
            <section class="content">
                <div class='row'>
                    <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                  <div class="box-header with-border">
                    <h3 class="box-title">Update Menu</h3>
                  </div><!-- /.box-header -->
                  <!-- form start -->
                  <form role="form" method="post" action="<?php echo Request::base_url()."/".$uri[0]."/".$uri[1];?>">
                    <div class="box-body">
                      <div class="form-group">
                        <input type="hidden" name="id" value="<?php echo $menu->id;?>"/>
                        <label for="name">Menu Name</label>
                        <input type="text" value="<?php echo $menu->name;?>" class="form-control" id="name" name="name" placeholder="Enter Menu" required="required">
                      </div>
                      <div class="form-group">
                        <label for="publish">Publish</label>
                        <select class="form-control" id="publish" name="publish">
                            <option value="1"  <?php if($menu->publish==1) echo "selected";?>>Yes</option>
                            <option value="0"  <?php if($menu->publish==0) echo "selected";?>>No</option>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="publish">Parent</label>
                        <select class="form-control" id="parent" name="parent">
                            <?php 
                            if(empty($menulist)){ ?>
                                <option value="">None</option>
                            <?php
                            
                            }else{
                                echo '<option value="">None</option>';
                                foreach($menulist as $m): ?>
                                
                                <option value="<?php echo $m->id;?>" <?php if($m->id==$menu->isparent) echo "selected";?>><?php echo $m->name; ?></option>
                            <?php endforeach; 
                            }?>
                        </select>
                      </div>
                    </div><!-- /.box-body -->
                    </div><!-- /.box-body -->

                    <div class="box-footer">
                      <button type="submit" class="btn btn-primary">Save</button>
                      <a href="<?php echo Request::base_url()."/".$uri[0]."/all";?>" class="btn btn-default">Back</a>
                    </div>
                  </form>
                </div><!-- /.box -->

              </div><!--/.col (left) -->
                </div>
            </section>
        <?php
        break;
    
    case "delete":
        $warn="";
        $checkparent=DBDriver::all("SELECT `id`, `name`, `isparent` FROM `menu` WHERE isparent=id", array(':id' => $uri[2]));
        if(empty($checkparent)){
            $menu=DBDriver::row("SELECT `id`, `name`, `isparent` FROM `menu` WHERE id=:id", array(':id' => $uri[2]));
            $warn="";
            echo "empty";
        }else{
            $warn="Cannot delete menu because it is parent of other menu";
        }
        ?><section class="content-header">
            <h1>
                Manage Menu
              </h1>
              <ol class="breadcrumb">
                <li><a href="<?php echo Request::base_url();?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo Request::base_url()."/".$uri[0]."/all";?>">Menu</a></li>
                <li class="active">Delete</li>
              </ol>
            </section>
            <section class="content">
                <div class='row'>
                    <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                  <div class="box-header with-border">
                    <h3 class="box-title">Delete Menu : </h3>
                  </div><!-- /.box-header -->
                  <!-- form start -->
                  <form role="form" method="post" action="<?php echo Request::base_url()."/".$uri[0]."/".$uri[1];?>">
                    <div class="box-body">
                      <div class="form-group">
                        <input type="hidden" name="id" value="<?php echo $menu->id;?>" />
                        <label for="name">Menu Name</label>
                        <input type="text" value="<?php echo $menu->name;?>" class="form-control" id="name" name="name" placeholder="Enter Category"readonly="true">
                      </div>
                    </div><!-- /.box-body -->

                    <div class="box-footer">
                      
                      <?php if($warn==""){ ?>
                      <label>Are you sure to delete this name? </label>
                      <button type="submit" class="btn btn-danger">Delete</button>
                      <?php } else {
                       echo "<label class='label label-warning'>".$warn."</label>" ;  
                      }?>
                      <a href="<?php echo Request::base_url()."/".$uri[0]."/all";?>" class="btn btn-default">Back</a>
                    </div>
                  </form>
                </div><!-- /.box -->

              </div><!--/.col (left) -->
                </div>
            </section>
        <?php
        break;
}
echo "</div>";
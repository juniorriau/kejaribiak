<?php
echo "<div class='content-wrapper'>";
switch ($uri[1]) {
    case "all":
        $page=  DBDriver::all("SELECT `id`, `title`, `dateadd`, `datemodified`, `publish`, `isparent` FROM `pages` ORDER BY `id`");
        ?>           
            <!-- Content Header (Page header) -->
            <section class="content-header">
              <h1>
                Manage Page
              </h1>
              <ol class="breadcrumb">
                <li><a href="<?php echo Request::base_url();?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo Request::base_url()."/".$uri[0]."/all";?>">Page</a></li>
                <li class="active">View</li>
              </ol>
            </section>

            <!-- Main content -->
            <section class="content">
              <div class="row">
                <div class="col-xs-12">

                  <div class="box">
                    <div class="box-body">
                      <table id="data" class="table table-bordered table-striped">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>Page Name</th>
                            <th>Date Add</th>
                            <th>Date Add</th>
                            <th>Publish</th>
                            <th>Parent Page</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $row = 1;
                            foreach($page as $p): ?>
                          <tr>
                            <td><?php echo $row;?></td>
                            <td><?php echo $p->title;?></td>
                            <td><?php echo $p->dateadd;?></td>
                            <td><?php echo $p->datemodified;?></td>
                            <td><?php echo $p->publish ? 'Yes' : 'No'; ?></td>
                            <td><?php echo $p->isparent;?></td>
                            <td style="min-width: 108px;">
                                <a class="btn btn-success btn-sm" title="Preview" target="new" href="<?php echo $siteurl.'preview/pages/'.$p->id;?>"><span class="glyphicon glyphicon-eye-close"></a>
                                <a class="btn btn-primary btn-sm" title="Edit" href="<?php echo Request::base_url().'/'.$uri[0]."/update/".$p->id;?>"><span class="glyphicon glyphicon-pencil"></a>
                                <a class="btn btn-danger btn-sm" title="Delete" href="<?php echo Request::base_url().'/'.$uri[0]."/delete/".$p->id;?>"><span class="glyphicon glyphicon-trash"></a>
                            </td>
                          </tr>
                          <?php $row++; endforeach; ?>
                        </tbody>
                      </table>
                    </div><!-- /.box-body -->
                  </div><!-- /.box -->
                </div><!-- /.col -->
              </div><!-- /.row -->
            </section><!-- /.content -->
        
        <?php
        break;
        
    case "add":
        $menu=  DBDriver::all("SELECT `id`, `title`, `publish` FROM `pages` WHERE isparent=0 ORDER by `id` Asc");
        ?>
            <section class="content-header">
                <h1>
                Manage Page
              </h1>
              <ol class="breadcrumb">
                <li><a href="<?php echo Request::base_url();?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo Request::base_url()."/".$uri[0]."/all";?>">Page</a></li>
                <li class="active">Add</li>
              </ol>
            </section>
            <section class="content">
                <div class='row'>
                    <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                  <div class="box-header with-border">
                    <h3 class="box-title">Add Page</h3>
                  </div><!-- /.box-header -->
                  <!-- form start -->
                  <form role="form" method="post" action="<?php echo Request::base_url()."/".$uri[0]."/".$uri[1];?>">
                    <div class="box-body">
                      <div class="form-group">
                        <label for="title">Page Name</label>
                        <input type="text" class="form-control" id="title" name="title" placeholder="Enter Page" required="required">
                      </div>
                      <div class="form-group">
                        <label for="tags">Page Content</label>
                        <textarea id="editor" name="editor" rows="10" cols="80">
                        </textarea>
                      </div>
                      <div class="form-group">
                        <label for="tags">Tags</label>
                        <input type="text" class="form-control" id="tags" name="tags" placeholder="Enter Tags, separate with comma">
                      </div>
                      <div class="form-group">
                        <label for="publish">Publish</label>
                        <select class="form-control" id="publish" name="publish">
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="publish">In Menu</label>
                        <select class="form-control" id="isparent" name="isparent">
                            <?php 
                            if(empty($menu)){ ?>
                                <option value="">None</option>
                            <?php
                            
                            }else{
                                ?><option value="0">None</option><?php
                                foreach($menu as $m): ?>
                                <option value="<?php echo $m->id;?>" ><?php echo $m->title; ?></option>
                            <?php endforeach; 
                            }?>
                        </select>
                      </div>
                      <div class="form-group">
                        <div class="col-lg-10">
                            <label>
                                <input type="checkbox" id="useascat" name="useascat"> Use as category?
                            </label>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="col-lg-10">
                            <label>
                                <input type="checkbox" id="loadpost" name="loadpost"> Autoload Post on Pages?
                            </label>
                        </div>
                      </div>  
                    </div><!-- /.box-body -->

                    <div class="box-footer">
                      <button type="submit" class="btn btn-primary">Submit</button>
                      <button type="reset" class="btn btn-warning">Reset</button>
                    </div>
                  </form>
                </div><!-- /.box -->

              </div><!--/.col (left) -->
                </div>
            </section>
            <?php
        break;
    
    case "update":
        $page=DBDriver::row("SELECT `id`, `title`, `content`, `tag`, `publish`, `isparent`, `autoloadpost`, `useascategory` FROM `pages` WHERE id=:id", array(':id' => $uri[2]));
        $menu=  DBDriver::all("SELECT `id`, `title`, `publish` FROM `pages` WHERE isparent=0 ORDER by `id` Asc");
        ?><section class="content-header">
              <h1>
                Manage Page
              </h1>
              <ol class="breadcrumb">
                <li><a href="<?php echo Request::base_url();?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo Request::base_url()."/".$uri[0]."/all";?>">Page</a></li>
                <li class="active">Update </li>
              </ol>
            </section>
            <section class="content">
                <div class='row'>
                    <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                  <div class="box-header with-border">
                    <h3 class="box-title">Update Page :</h3>
                  </div><!-- /.box-header -->
                  <!-- form start -->
                  <form role="form" method="post" action="<?php echo Request::base_url()."/".$uri[0]."/".$uri[1];?>">
                    <div class="box-body">
                      <div class="form-group">
                        <label for="title">Page Name</label>
                        <input type="hidden" name="id" value="<?php echo $page->id;?>"/>
                        <input type="text" value="<?php echo $page->title;?>" class="form-control" id="title" name="title" placeholder="Enter Page" required="required">
                      </div>
                      <div class="form-group">
                        <label for="tags">Page Content</label>
                        <textarea id="editor" name="editor" rows="10" cols="80"><?php echo $page->content;?>
                        </textarea>
                      </div>
                      <div class="form-group">
                        <label for="tags">Tags</label>
                        <input type="text" value="<?php echo $page->tag;?>" class="form-control" id="tags" name="tags" placeholder="Enter Tags, separate with comma">
                      </div>
                      <div class="form-group">
                        <label for="publish">Publish</label>
                        <select class="form-control" id="publish" name="publish">
                            <option value="1"  <?php if($page->publish==1) echo "selected";?>>Yes</option>
                            <option value="0"  <?php if($page->publish==0) echo "selected";?>>No</option>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="publish">In Menu</label>
                        <select class="form-control" id="isparent" name="isparent">
                            <?php 
                            if(empty($menu)){ ?>
                                <option value="">None</option>
                            <?php
                            
                            }else{
                                ?><option value="0">None</option><?php
                                foreach($menu as $m): ?>
                                
                                <option value="<?php echo $m->id;?>" <?php if($m->id==$page->isparent) echo "selected";?>><?php echo $m->title; ?></option>
                            <?php endforeach; 
                            }?>
                        </select>
                      </div>
                      <div class="form-group">
                        <div class="col-lg-10">
                            <label>
                                <input type="checkbox" id="useascat" name="useascat" <?php if($page->useascategory=='Yes') echo "checked"?>> Use as category?
                            </label>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="col-lg-10">
                            <label>
                                <input type="checkbox" id="loadpost" name="loadpost" <?php if($page->autoloadpost=='on') echo "checked"?>> Autoload Post on Pages?
                            </label>
                        </div>
                      </div>
                    </div><!-- /.box-body -->

                    <div class="box-footer">
                      <button type="submit" class="btn btn-primary">Save</button>
                      <a href="<?php echo Request::base_url()."/".$uri[0]."/all";?>" class="btn btn-default">Back</a>
                    </div>
                  </form>
                </div><!-- /.box -->

              </div><!--/.col (left) -->
                </div>
            </section>
        <?php
        break;
    
    case "delete":
        $page=DBDriver::row("SELECT `id`, `title` FROM `pages` WHERE id=:id", array(':id' => $uri[2]));
        ?><section class="content-header">
              <h1>
                Manage Page
              </h1>
              <ol class="breadcrumb">
                <li><a href="<?php echo Request::base_url();?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo Request::base_url()."/".$uri[0]."/all";?>">Page</a></li>
                <li class="active">Delete</li>
              </ol>
            </section>
            <section class="content">
                <div class='row'>
                    <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                  <div class="box-header with-border">
                    <h3 class="box-title">Delete Page : </h3>
                  </div><!-- /.box-header -->
                  <!-- form start -->
                  <form role="form" method="post" action="<?php echo Request::base_url()."/".$uri[0]."/".$uri[1];?>">
                    <div class="box-body">
                      <div class="form-group">
                        <input type="hidden" name="id" value="<?php echo $page->id;?>" />
                        <label for="title">Page Name</label>
                        <input type="text" value="<?php echo $page->title;?>" class="form-control" id="title" name="title" placeholder="Enter Page"readonly="true">
                      </div>
                    </div><!-- /.box-body -->

                    <div class="box-footer">
                        <label>Are you sure to delete this title? </label>
                      <button type="submit" class="btn btn-danger">Delete</button>
                      <a href="<?php echo Request::base_url()."/".$uri[0]."/all";?>" class="btn btn-default">Back</a>
                    </div>
                  </form>
                </div><!-- /.box -->

              </div><!--/.col (left) -->
                </div>
            </section>
        <?php
        break;
}
echo "</div>";
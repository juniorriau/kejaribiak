<?php
echo "<div class='content-wrapper'>";
switch ($uri[1]) {
    case "all":
        $post=  DBDriver::all("SELECT ps.`id`, ps.`title`, ps.`content`, cs.category, ps.`dateadd`, ps.`datemodified`, ps.`publish`, ps.`allowcomment`  FROM `posts` ps, categories cs Where ps.category=cs.id ORDER BY id");
        ?>           
            <!-- Content Header (Post header) -->
            <section class="content-header">
              <h1>
                Manage Post
              </h1>
              <ol class="breadcrumb">
                <li><a href="<?php echo Request::base_url();?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo Request::base_url()."/".$uri[0]."/all";?>">Post</a></li>
                <li class="active">View</li>
              </ol>
            </section>

            <!-- Main content -->
            <section class="content">
              <div class="row">
                <div class="col-xs-12">

                  <div class="box">
                    <div class="box-body">
                      <table id="data" class="table table-bordered table-striped">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Date Add</th>
                            <th>Publish</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $row = 1;
                            foreach($post as $p): ?>
                          <tr>
                            <td><?php echo $row;?></td>
                            <td><?php echo $p->title;?></td>
                            <td><?php echo $p->category;?></td>
                            <td><?php echo $p->dateadd;?></td>
                            <td><?php echo $p->publish ? 'Yes' : 'No'; ?></td>
                            <td style="min-width: 108px;">
                                <a class="btn btn-success btn-sm" title="Preview" target="new" href="<?php echo $siteurl.'preview/posts/'.$p->id;?>"><span class="glyphicon glyphicon-eye-close"></a>
                                <a class="btn btn-primary btn-sm" title="Edit" href="<?php echo Request::base_url().'/'.$uri[0]."/update/".$p->id;?>"><span class="glyphicon glyphicon-pencil"></a>
                                <a class="btn btn-danger btn-sm" title="Delete" href="<?php echo Request::base_url().'/'.$uri[0]."/delete/".$p->id;?>"><span class="glyphicon glyphicon-trash"></a>
                            </td>
                          </tr>
                          <?php $row++; endforeach; ?>
                        </tbody>
                      </table>
                    </div><!-- /.box-body -->
                  </div><!-- /.box -->
                </div><!-- /.col -->
              </div><!-- /.row -->
            </section><!-- /.content -->
        
        <?php
        break;
        
    case "add":
        $cat=  DBDriver::all("SELECT `id`, `category` FROM `categories` ORDER by `id` Asc");
        ?>
            <section class="content-header">
                <h1>
                Manage Post
              </h1>
              <ol class="breadcrumb">
                <li><a href="<?php echo Request::base_url();?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo Request::base_url()."/".$uri[0]."/all";?>">Post</a></li>
                <li class="active">Add</li>
              </ol>
            </section>
            <section class="content">
                <div class='row'>
                    <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                  <div class="box-header with-border">
                    <h3 class="box-title">Add Post</h3>
                  </div><!-- /.box-header -->
                  <!-- form start -->
                  <form role="form" method="post" action="<?php echo Request::base_url()."/".$uri[0]."/".$uri[1];?>">
                    <div class="box-body">
                      <div class="form-group">
                        <label for="title">Post Name</label>
                        <input type="text" class="form-control" id="title" name="title" placeholder="Enter Post" required="required">
                      </div>
                      <div class="form-group">
                        <label for="tags">Post Content</label>
                        <textarea id="editor" name="editor" rows="10" cols="80">
                        </textarea>
                      </div>
                      <div class="form-group">
                        <label for="tags">Tags</label>
                        <input type="text" class="form-control" id="tags" name="tags" placeholder="Enter Tags, separate with comma">
                      </div>
                      <div class="form-group">
                        <label for="image">Image Name</label>
                        <input type="text" class="form-control" id="image" name="image" placeholder="Enter image name">
                      </div>
                      <div class="form-group">
                        <label for="publish">Publish</label>
                        <select class="form-control" id="publish" name="publish">
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="publish">Category</label>
                        <select class="form-control" id="category" name="category">
                            <?php 
                            if(empty($cat)){ ?>
                                <option value="">None</option>
                            <?php
                            
                            }else{
                                ?><option value="0">None</option><?php
                                foreach($cat as $c): ?>
                                <option value="<?php echo $c->id;?>" ><?php echo $c->category; ?></option>
                            <?php endforeach; 
                            }?>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="publish">Allow Comment</label>
                        <select class="form-control" id="allow" name="allow">
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="publish">Date Add</label>
                        <div class="input-group date">
                            <div class="input-group-addon">
                              <i class="fa fa-calendar"></i>
                            </div>
                            <input type="text" class="form-control" id="datepost" name="datepost"/>
                        </div>
                        
                      </div>
                    </div><!-- /.box-body -->

                    <div class="box-footer">
                      <button type="submit" class="btn btn-primary">Submit</button>
                      <button type="reset" class="btn btn-warning">Reset</button>
                    </div>
                  </form>
                </div><!-- /.box -->

              </div><!--/.col (left) -->
                </div>
            </section>
            <?php
        break;
    
    case "update":
        $post=DBDriver::row("SELECT `id`, `title`, `content`, `category`, `tag`, `filename`, `publish`, `allowcomment`, `dateadd` FROM `posts` WHERE id=:id", array(':id' => $uri[2]));
        $cat=  DBDriver::all("SELECT `id`, `category` FROM `categories` ORDER by `id` Asc");
        ?><section class="content-header">
              <h1>
                Manage Post
              </h1>
              <ol class="breadcrumb">
                <li><a href="<?php echo Request::base_url();?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo Request::base_url()."/".$uri[0]."/all";?>">Post</a></li>
                <li class="active">Update </li>
              </ol>
            </section>
            <section class="content">
                <div class='row'>
                    <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                  <div class="box-header with-border">
                    <h3 class="box-title">Update Post :</h3>
                  </div><!-- /.box-header -->
                  <!-- form start -->
                  <form role="form" method="post" action="<?php echo Request::base_url()."/".$uri[0]."/".$uri[1];?>">
                   <div class="box-body">
                      <div class="form-group">
                        <label for="title">Post Name</label>
                        <input type="hidden" value="<?php echo $post->id;?>" name="id"/>
                        <input type="text" value="<?php echo $post->title;?>" class="form-control" id="title" name="title" placeholder="Enter Post" required="required">
                      </div>
                      <div class="form-group">
                        <label for="tags">Post Content</label>
                        <textarea id="editor" name="editor" rows="10" cols="80"><?php echo $post->content;?>
                        </textarea>
                      </div>
                      <div class="form-group">
                        <label for="tags">Tags</label>
                        <input type="text" value="<?php echo $post->tag;?>" class="form-control" id="tags" name="tags" placeholder="Enter Tags, separate with comma">
                      </div>
                      <div class="form-group">
                        <label for="image">Image Name</label>
                        <input type="text" value="<?php echo $post->filename;?>" class="form-control" id="image" name="image" placeholder="Enter image name">
                      </div>
                      <div class="form-group">
                        <label for="publish">Publish</label>
                        <select class="form-control" id="publish" name="publish">
                            <option value="1"  <?php if($post->publish==1) echo "selected";?>>Yes</option>
                            <option value="0"  <?php if($post->publish==0) echo "selected";?>>No</option>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="publish">Category</label>
                        <select class="form-control" id="category" name="category">
                            <?php 
                            if(empty($cat)){ ?>
                                <option value="">None</option>
                            <?php
                            
                            }else{
                                ?><option value="0">None</option><?php
                                foreach($cat as $c): ?>
                                <option value="<?php echo $c->id;?>" <?php if($c->id==$post->category) echo "selected";?>><?php echo $c->category; ?></option>
                            <?php endforeach; 
                            }?>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="publish">Allow Comment </label>
                        <select class="form-control" id="allow" name="allow">
                            <option value="1"  <?php if($post->allowcomment==1) echo "selected";?>>Yes</option>
                            <option value="0"  <?php if($post->allowcomment==0) echo "selected";?>>No</option>
                        </select>
                      </div>
                      
                       <div class="form-group">
                        <label for="datepsot">Date Add </label>
                        <div class="input-group date">
                            <div class="input-group-addon">
                              <i class="fa fa-calendar"></i>
                            </div>
                            <input type="text" class="form-control" id="datepost" name="datepost" value="<?php echo $post->dateadd?>"/>
                        </div>
                        
                      </div>
                    </div><!-- /.box-body -->

                    <div class="box-footer">
                      <button type="submit" class="btn btn-primary">Save</button>
                      <a href="<?php echo Request::base_url()."/".$uri[0]."/all";?>" class="btn btn-default">Back</a>
                    </div>
                  </form>
                </div><!-- /.box -->

              </div><!--/.col (left) -->
                </div>
            </section>
        <?php
        break;
    
    case "delete":
        $post=DBDriver::row("SELECT `id`, `title` FROM `pages` WHERE id=:id", array(':id' => $uri[2]));
        ?><section class="content-header">
              <h1>
                Manage Post
              </h1>
              <ol class="breadcrumb">
                <li><a href="<?php echo Request::base_url();?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo Request::base_url()."/".$uri[0]."/all";?>">Post</a></li>
                <li class="active">Delete</li>
              </ol>
            </section>
            <section class="content">
                <div class='row'>
                    <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                  <div class="box-header with-border">
                    <h3 class="box-title">Delete Post : </h3>
                  </div><!-- /.box-header -->
                  <!-- form start -->
                  <form role="form" method="post" action="<?php echo Request::base_url()."/".$uri[0]."/".$uri[1];?>">
                    <div class="box-body">
                      <div class="form-group">
                        <input type="hidden" name="id" value="<?php echo $post->id;?>" />
                        <label for="title">Post Name</label>
                        <input type="text" value="<?php echo $post->title;?>" class="form-control" id="title" name="title" placeholder="Enter Post"readonly="true">
                      </div>
                    </div><!-- /.box-body -->

                    <div class="box-footer">
                        <label>Are you sure to delete this title? </label>
                      <button type="submit" class="btn btn-danger">Delete</button>
                      <a href="<?php echo Request::base_url()."/".$uri[0]."/all";?>" class="btn btn-default">Back</a>
                    </div>
                  </form>
                </div><!-- /.box -->

              </div><!--/.col (left) -->
                </div>
            </section>
        <?php
        break;
}
echo "</div>";
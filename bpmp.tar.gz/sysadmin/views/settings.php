<?php
echo "<div class='content-wrapper'>";
switch ($uri[1]) {
    case "all":
        $setting=  DBDriver::all("SELECT `description`, `keyvalue` FROM `settings`");
        ?>           
            <!-- Content Header (Page header) -->
            <section class="content-header">
              <h1>
                Setting Overview
              </h1>
              <ol class="breadcrumb">
                <li><a href="<?php echo Request::base_url();?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo Request::base_url()."/".$uri[0]."/all";?>">Setting</a></li>
                <li class="active">View</li>
              </ol>
            </section>

            <!-- Main content -->
            <section class="content">
              <div class="row">
                <div class="col-xs-12">

                  <div class="box">
                    <div class="box-body">
                        <a href="<?php echo Request::base_url();?>/settings/update" class="btn btn-info margin-bottom"><i class="fa fa-gears"></i> Update Setting</a>
                        <table id="data" class="table table-bordered table-striped">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>Seting Name</th>
                            <th>Seting Value</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $row = 1;
                            foreach($setting as $s): ?>
                          <tr>
                            <td><?php echo $row;?></td>
                            <td><?php echo $s->description;?></td>
                            <td><?php echo $s->keyvalue;?></td>
                          </tr>
                          <?php $row++; endforeach; ?>
                        </tbody>
                        </table>
                    </div><!-- /.box-body -->
                  </div><!-- /.box -->
                </div><!-- /.col -->
              </div><!-- /.row -->
            </section><!-- /.content -->
        
        <?php
        break;
    
    case "update":
        $setting=DBDriver::all("SELECT `description`, `keyname`, `keyvalue` FROM `settings`");
        ?><section class="content-header">
              <h1>
                Setting
              </h1>
              <ol class="breadcrumb">
                <li><a href="<?php echo Request::base_url();?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo Request::base_url()."/".$uri[0]."/all";?>">Setting</a></li>
                <li class="active">Update</li>
              </ol>
            </section>
            <section class="content">
                <div class='row'>
                    <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                  <div class="box-header with-border">
                    <h3 class="box-title">Update Setting :</h3>
                  </div><!-- /.box-header -->
                  <!-- form start -->
                  <form role="form" method="post" action="<?php echo Request::base_url()."/".$uri[0]."/".$uri[1];?>">
                    <div class="box-body">
                        <?php
                        foreach($setting as $s): ?>
                      <div class="form-group">
                        <label for="<?php echo $s->keyname;?>"><?php echo $s->description;?></label>
                        <input type="text" value="<?php echo $s->keyvalue;?>" class="form-control" id="<?php echo $s->keyname;?>" name="<?php echo $s->keyname;?>">
                      </div>
                        <?php endforeach; ?>
                    </div><!-- /.box-body -->

                    <div class="box-footer">
                      <button type="submit" class="btn btn-primary">Save</button>
                      <a href="<?php echo Request::base_url()."/".$uri[0]."/all";?>" class="btn btn-default">Back</a>
                    </div>
                  </form>
                </div><!-- /.box -->

              </div><!--/.col (left) -->
                </div>
            </section>
        <?php
        break;
}
echo "</div>";
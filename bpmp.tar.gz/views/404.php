<div class="col-md-12">
    <div class="alert alert-dismissible alert-danger">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong>Galat!</strong> Artikel tidak ditemukan!.
    </div>
</div>
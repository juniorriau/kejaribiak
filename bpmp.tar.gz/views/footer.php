<!-- Javascript
–––––––––––––––––––––––––––––––––––––––––––––––––– -->
	<script type="text/javascript" src="<?php echo Request::base_url();?>/assets/js/modernizr.min.js"></script>
	<script type="text/javascript" src="<?php echo Request::base_url();?>/assets/js/owl.carousel.min.js"></script>
	<!--<script type="text/javascript" src="<?php echo Request::base_url();?>/assets/js/isotope.min.js"></script>
    <script type="text/javascript" src="<?php echo Request::base_url();?>/assets/js/jquery.jribbble-1.0.1.ugly.js"></script> -->
	<script type="text/javascript" src="<?php echo Request::base_url();?>/assets/js/jquery.bxslider.min.js"></script>
	<script type="text/javascript" src="<?php echo Request::base_url();?>/assets/js/hamzh.min.js"></script>
</body>
</html>
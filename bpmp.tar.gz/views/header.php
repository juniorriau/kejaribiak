<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]>
<!--> <!--<![endif]-->
<html lang="en">
<head>

  <!-- Basic Page Needs
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
    <meta charset="utf-8">
    <title><?php echo $sitetitle;?></title>
    <meta name="description" content="<?php echo $sitetitle;?>">
    <meta name="author" content="">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="ROBOTS" content="index" /> 
    <meta content="id" name="language"/>
    <meta name="googlebot" content="NOODP, follow" />
    <meta name="og:image" content="<?php echo Request::base_url()."/assets/upload/".$themes_quote_image;?>" />
    <meta name="image" content="<?php echo Request::base_url()."/assets/upload/".$themes_quote_image;?>" />
    <meta name="Keywords" content="BPMP Riau, BPMP BangDes Riau, <?php echo $sitetitle;?>" />
    <meta name="Author" content="BPMP Riau, BPMPBangDes Riau" />
    <meta name="language" content="Indonesian, English" />
    <meta name="distribution" content="Global" />
    <meta name="rating" content="General" />
    <meta name="expires" content="never" />
    <!-- Mobile Specific Metas
    –––––––––––––––––––––––––––––––––––––––––––––––––– -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSS
    –––––––––––––––––––––––––––––––––––––––––––––––––– -->
    <link rel="stylesheet" type="text/css" href="<?php echo Request::base_url();?>/assets/css/style.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo Request::base_url();?>/assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo Request::base_url();?>/assets/css/bootstrap-theme.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo Request::base_url();?>/assets/css/font-awesome.min.css">

    <!-- Favicon
    –––––––––––––––––––––––––––––––––––––––––––––––––– -->
    <link rel="icon" type="image/png" href="<?php echo Request::base_url();?>/assets/img/favicon.ico">

    <!-- Javascript
    –––––––––––––––––––––––––––––––––––––––––––––––––– -->
    <script type="text/javascript" src="<?php echo Request::base_url();?>/assets/js/jquery.v2.1.3.min.js"></script>
    <script type="text/javascript" src="<?php echo Request::base_url();?>/assets/js/bootstrap.min.js"></script>

</head>
<?php
if(Request::isGet()){
    require 'header.php';
    $nav=  DBDriver::all("SELECT `id`, `title`, `permalink`, `publish` FROM `pages` WHERE `publish` = 1 AND `isparent`= 0");
    $latestnews=  DBDriver::all("SELECT title,content,permalink,filename, dateadd, DATE_FORMAT(dateadd ,'%d %b %Y') as date FROM posts WHERE publish=1 order by dateadd desc limit 0,5");
    $slide=DBDriver::all("SELECT title,content,permalink,filename FROM posts WHERE publish=1 order by dateadd desc limit 0,".$slidenum);
    $news=  DBDriver::all("SELECT ps.title,ps.content,ps.permalink,ps.filename, ps.dateadd, DATE_FORMAT(ps.dateadd ,'%d %b %Y') as date, cs.category FROM posts ps, categories cs WHERE ps.category=cs.id AND ps.publish=1 order by ps.dateadd desc limit 0,".$slidenum);

    if($uri[0]==""){
        $posts=  DBDriver::all("SELECT ps.title,ps.content,ps.permalink,ps.filename, ps.dateadd, DATE_FORMAT(ps.dateadd ,'%d %b %Y') as date, cs.category FROM posts ps, categories cs WHERE ps.category=cs.id AND ps.publish=1 order by ps.dateadd desc limit 0,9");
        require 'mainbody.php';
    }

   else{
        switch ($uri[0]) {
            case "pages":
                $content=  DBDriver::row("SELECT title, DATE_FORMAT(dateadd ,'%d %b %Y') as date, title as category,content,permalink,autoloadpost,useascategory FROM pages WHERE permalink=:permalink",array(
                    ":permalink"=>$uri[1],
                ));
                if(empty($content)){
                    include 'maincontent.php';
                }
                else{
                    if($content->autoloadpost=="on"){
                        $posts=  DBDriver::all("SELECT ps.title FROM posts ps, categories cs WHERE ps.category=cs.id AND ps.publish=1 order by ps.dateadd desc");
                        include 'listcontent.php';
                    }
                    elseif($content->useascategory=="Yes"){
                        $cat=  DBDriver::row("SELECT id FROM categories WHERE category=:category",array(
                                ':category'=>  $content->title,
                        ));
                        $relatedpost =  DBDriver::all("SELECT ps.title,ps.permalink,ps.filename, ps.dateadd, DATE_FORMAT(ps.dateadd ,'%d %b %Y') as date FROM posts ps, categories cs WHERE ps.category=cs.id AND cs.id=:category AND ps.publish=1 order by ps.dateadd desc",array(
                            ":category"=>$cat->id,));
                        include 'maincontent.php';
                    }
                    else{
                        include 'maincontent.php';
                    }    
                }
            break;
            case "posts":
                $content=  DBDriver::row("SELECT ps.title,ps.content,ps.permalink,ps.filename, ps.dateadd, DATE_FORMAT(ps.dateadd ,'%d %b %Y') as date, cs.category FROM posts ps, categories cs WHERE ps.category=cs.id AND ps.publish=1 AND permalink=:permalink",array(
                    ":permalink"=>$uri[1],
                ));
                include 'maincontent.php';
            break;
            /*case "category":
                $content=  DBDriver::row("SELECT id,category FROM categories WHERE category=:category",array(
                    ":category"=>str_replace("-"," ",$uri[1]),
                ));
                include 'listcontent.php';
            break; */
            case "preview":
                if($uri[1]=="pages"){
                    $content = DBDriver::row("SELECT id,title,content,tag FROM ".$uri[1]." WHERE id=:id", array(
                ":id" => $uri[2],
                    ));
                }
                else{
                    $content = DBDriver::row("SELECT id,title,content,tag,filename FROM ".$uri[1]." WHERE id=:id", array(
                ":id" => $uri[2],
                    ));
                }
                include 'maincontent.php';
            break;
        }
    }
    require 'footer.php';
}elseif (Request::isPost()) {
    if(file_exists($baseInc['controllers']."/".$uri[0].".php")){
        include $baseInc['controllers']."/".$uri[0].".php";   
    }
}

<div class="all_content animsition container-fluid">
		<div class="row">

			<div class="header"><!-- Start header -->
				<div class="top_bar"><!-- Start top_bar -->
					<div class="min_top_bar"><!-- Start min_top_bar -->
						<div class="container">

						</div>
					</div><!-- End min_top_bar -->
				</div><!-- End top_bar -->

				<div class="main_header"><!-- Start main_header -->
					<div class="container">

						<div class="banner_logo">
                            <a href="#"><img src="<?php echo Request::base_url();?>/assets/img/header.jpg" alt="ads"></a>
                        </div>

						<?php require 'menu.php';?>
						
					</div>
				</div><!-- End main_header -->
			</div><!-- End header -->

			<div class="main_content container">
                <!--<div class="maps_content">
                        <div class="col-md-7">
                            <img class="banner-responsive" usemap="#mapriau" src="<?php echo Request::base_url();?>/assets/img/peta-administrasi-riau.jpg">
                        </div>
                        <div class="col-md-5">

                        </div>
                </div> -->
                <!--Start Mian slider -->
				<?php require 'mainslide.php';?>

				<div class="posts_sidebar list_layout layout_left_side clearfix">
                    <!--Start Side Area -->
					<?php require 'sidecontent.php';?>

					<!--Start Posts Areaa -->
					<div class="posts_areaa list_layout_left col-md-8">
						<div class="row">
                        <?php
                        if(empty($posts)){ ?>
                            <div class="col-md-12">
                                <div class="alert alert-dismissible alert-warning">
                                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                                    <strong>Galat!</strong> Tidak ada artikel dipublis!.
                                </div>
                            </div>
                        <?php
                        
                        }
                        else{
                            foreach($posts as $p):
                            ?>
                            <article class="hz_post">
								<div class="standard_post">
									<div class="list_thum">
										<div class="hz_thumb_post">
											<div class="cat_list_post">
												<span class="hz_cat_post">
													<a href="<?php echo Request::base_url()."/".Configuration::get("slugcat")."/".  str_replace(" ", "-", $p->category);?>"s><?php echo $p->category;?></a>
												</span>
											</div>

											<img src="<?php echo Request::base_url()."/assets/upload/".$p->filename;?>" class="img-responsive" alt="Responsive image">
										</div>	
									</div>	
									<div class="list_content">
										<div class="hz_top_post">
											<div class="hz_title_and_meta">
												<div class="hz_title"><h4><a href="<?php echo Request::base_url()."/".Configuration::get("slugpost")."/".$p->permalink;?>"><?php echo $p->title;?></a></h4></div>
												<div class="hz_meta_post">
													<span class="hz_post_by"><i class="fa fa-user"></i><a href="#">Admin</a></span>
													<span class="hz_date_post"><i class="fa fa-calendar"></i><a href="#"><?php echo $p->date;?></a></span>
												</div>
											</div>
										</div>

										<div class="hz_main_post_content">
											<div class="hz_content">
												<p><?php echo substr($p->content, 0, 100);?> ...</p>

											</div>

											<div class="hz_bottom_post">

												<div class="hz_read_more">
													<a href="<?php echo Request::base_url()."/".Configuration::get("slugpost")."/".$p->permalink;?>"><i class="fa fa-paper-plane-o"></i> Baca Lebih Lanjut</a>
												</div>

												<div class="hz_icon_shere">

				                                    <span class="share_toggle pi-btn">
				                                        <i class="fa fa-share-alt"></i>
				                                    </span>

				                                    <div class="hz_share">
														<span><a href="#"><i class="fa fa-facebook"></i></a></span>
														<span><a href="#"><i class="fa fa-twitter"></i></a></span>

												</div>

											</div>
										</div>
									</div>
								</div>
							</article>
                            <?php
                            endforeach;
                        }?>
							
						</div>	
					</div>
					<!--End Posts Areaa -->
				</div><!-- posts_sidebar -->
			</div><!-- main_content -->

			<div id="footer" class="footer container-fulid"><!-- Start footer -->
				<footer class="main_footer"><!-- Start main_footer -->
					<div class="container">
						<div class="row">

							<div class="col-sm-4"><!-- Start widget_text -->
								<div id="text-3" class="widget widget_text">
									<h4 class="widget_title"><?php echo $sitename;?></h4>
									<div class="social_icon">
                                        <p class="textwidget"><span><a ><i class="fa fa-paper-plane"></i></a></span> Jl H.R. Soebrantas KM 10 Pekanbaru</p>
                                        <p class="textwidget"><span><a ><i class="fa fa-phone"></i></a></span> Telepon (0761) 62705</p>
                                        <p class="textwidget"><span><a ><i class="fa fa-fax"></i></a></span> Fax 65839</p>
                                        <p class="textwidget"><span><a ><i class="fa fa-envelope"></i></a></span> info@bpmpbangdes.riau.go.id</p>
										</div>
								</div>	
							</div><!-- End widget_text -->
							
							<!--<div class="col-sm-4"><!-- Start widget tag cloud 
								<div class="widget  widget_tag_cloud">
									<h4 class="widget_title">Tags</h4>
									<div class="tagcloud">
										<a href="#">audio</a>
										<a href="#">dailymotion</a>
										<a href="#">Gallery</a>
										<a href="#">LightBox</a>
										<a href="#">Link</a>
										<a href="#">mp3</a>
										<a href="#">nature</a>
										<a href="#">post</a>
										<a href="#">Quote</a>
										<a href="#">slider</a>
										<a href="#">soundcloud</a>
										<a href="#">sport</a>
										<a href="#">Standard</a>
										<a href="#">Twitter</a>
										<a href="#">vimeo</a>
									</div>
								</div>
							</div><!-- End widget tag cloud -->

						</div>
					</div>
				</footer><!-- End main_footer -->

				<div class="copyright"> <!-- Start copyright -->
					<div class="hmztop">Scroll To Top</div><!-- Back top -->
					<div class="footer_logo"><!-- Start footer logo -->
						<a href="#"><?php echo $sitename;?></a>
					</div><!-- End footer logo -->
					<div class="social_icon"><!--Start social_icon -->
						<span><a href="#"><i class="fa fa-facebook"></i></a></span>
						<span><a href="#"><i class="fa fa-twitter"></i></a></span>
					</div><!--End social_icon -->
					<p>Copyrights © 2015 All Rights Reserved by <a href="<?php echo $siteurl;?>"><?php echo $sitename;?></a></p>
				</div><!-- End copyright --> 
			</div><!-- End footer -->

		</div><!-- End row -->
	</div><!-- End all_content -->
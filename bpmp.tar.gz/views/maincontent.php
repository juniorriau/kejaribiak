<div class="all_content animsition container-fluid">
		<div class="row">

			<div class="header"><!-- Start header -->
				<div class="top_bar"><!-- Start top_bar -->
					<div class="min_top_bar"><!-- Start min_top_bar -->
						<div class="container">

						</div>
					</div><!-- End min_top_bar -->
				</div><!-- End top_bar -->

				<div class="main_header"><!-- Start main_header -->
					<div class="container">

						<div class="banner_logo">
                            <a href="#"><img src="<?php echo Request::base_url();?>/assets/img/header.jpg" alt="ads"></a>
                        </div>

						<?php require 'menu.php';?>
						
					</div>
				</div><!-- End main_header -->
			</div><!-- End header -->

			<div class="main_content container">

				<div class="posts_sidebar layout_left_sidebar clearfix"><!-- Start posts sidebar -->

					<!--Start Side Area -->
					<?php require 'sidecontent.php';?>

					<div class="inner_single col-md-8"> <!-- Start inner single -->
						<div class="row">	
						<?php
                        if(empty($content)){ ?>
                            <div class="col-md-12">
                                <div class="alert alert-dismissible alert-warning">
                                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                                    <strong>Galat!</strong> Tidak ada artikel dipublis!.
                                </div>
                            </div>
                        <?php
                        
                        }
                        else{ ?>
                            <article class="hz_post"><!-- Start article -->
								<div class="video_post post_wrapper">

									<?php
                                    if(isset($content->filename)){ ?>
                                    <div class="hz_thumb_post">
                                        <img class="img img-responsive" src="<?php echo Request::base_url()."/assets/upload/".$content->filename;?>"/>
									</div>
                                    <?php } ?>
									<div class="hz_top_post">

										<div class="hz_title_and_meta">
											<div class="hz_title"><h3><a href="<?php echo Request::base_url()."/".Configuration::get("slugpage")."/".$content->permalink;?>"><?php echo $content->title;?></a></h3></div>
											<div class="hz_meta_post">
												<span class="hz_post_by"><i class="fa fa-user"></i><a href="#">Admin</a></span>
												<span class="hz_date_post"><i class="fa fa-calendar"></i><a href="#"><?php echo $content->date;?></a></span>
											</div>
										</div>
									</div> 

									<div class="hz_main_post_content">
										<div class="hz_content">
											<?php echo $content->content;?>
										</div>

										<div class="hz_bottom_post">
                                            <?php
                                            if($uri[0]=="preview"){ ?>
                                            <button class="btn btn-sm btn-info" onclick="window.close()">Tutup Preview</button>
                                            <?php } ?>
											<!--<div class="hz_tags">
												<span><a href="#">Design</a></span>
												<span><a href="#">photoshop</a></span>
												<span><a href="#">HTML</a></span>
											</div>-->

											<div class="hz_icon_shere">
			                                    <span class="share_toggle pi-btn">
			                                        <i class="fa fa-share-alt"></i>
			                                    </span>
			                                    <div class="hz_share">
													<span><a href="#"><i class="fa fa-facebook"></i></a></span>
													<span><a href="#"><i class="fa fa-twitter"></i></a></span>
													<span><a href="#"><i class="fa fa-google-plus"></i></a></span>
													<span><a href="#"><i class="fa fa-stumbleupon"></i></a></span>
												</div>
											</div>
										</div>
									</div>
								</div>
							</article><!-- End article -->
                            <?php
                            if(isset($relatedpost)){ ?>
                            <div class="single_related_posts"><!-- Start Related Posts -->
									<div class="post_title"><h4>Artikel Terkait Bidang Ini</h4></div>

									<ul id="post_related_block" class="post_block">
										<?php
                                        foreach ($relatedpost as $rp){ ?>
										<li class="item">
											<div class="img_box">
												<a href="<?php echo Request::base_url()."/".Configuration::get("slugpost")."/".$rp->permalink;?>">
												<img src="<?php echo Request::base_url()."/assets/upload/".$rp->filename;?>" alt="<?php echo $rp->title;?>">
												</a>
											</div>
                                            <h5><a href="<?php echo Request::base_url()."/".Configuration::get("slugpost")."/".$rp->permalink;?>" style="color: #276197;"><?php echo $rp->title;?></a></h5>
											<span class="date"><?php echo $rp->date;?></span>
										</li>
                                        <?php } ?>
									</ul>
								</div><!-- End Related Posts -->
                                
                            <?php }}
                        ?>
							
									
						</div>	
					</div><!--End Posts Areaa -->
				</div><!-- End posts sidebar -->
			</div><!-- main_content -->

			<div id="footer" class="footer container-fulid"><!-- Start footer -->
				<footer class="main_footer"><!-- Start main_footer -->
					<div class="container">
						<div class="row">

							<div class="col-sm-4"><!-- Start widget_text -->
								<div id="text-3" class="widget widget_text">
									<h4 class="widget_title"><?php echo $sitename;?></h4>
									<div class="social_icon">
                                        <p class="textwidget"><span><a ><i class="fa fa-paper-plane"></i></a></span> Jl H.R. Soebrantas KM 10 Pekanbaru</p>
                                        <p class="textwidget"><span><a ><i class="fa fa-phone"></i></a></span> Telepon (0761) 62705</p>
                                        <p class="textwidget"><span><a ><i class="fa fa-fax"></i></a></span> Fax 65839</p>
                                        <p class="textwidget"><span><a ><i class="fa fa-envelope"></i></a></span> info@bpmpbangdes.riau.go.id</p>
										</div>
								</div>	
							</div><!-- End widget_text -->
							
							<!--<div class="col-sm-4"><!-- Start widget tag cloud 
								<div class="widget  widget_tag_cloud">
									<h4 class="widget_title">Tags</h4>
									<div class="tagcloud">
										<a href="#">audio</a>
										<a href="#">dailymotion</a>
										<a href="#">Gallery</a>
										<a href="#">LightBox</a>
										<a href="#">Link</a>
										<a href="#">mp3</a>
										<a href="#">nature</a>
										<a href="#">post</a>
										<a href="#">Quote</a>
										<a href="#">slider</a>
										<a href="#">soundcloud</a>
										<a href="#">sport</a>
										<a href="#">Standard</a>
										<a href="#">Twitter</a>
										<a href="#">vimeo</a>
									</div>
								</div>
							</div><!-- End widget tag cloud -->

						</div>
					</div>
				</footer><!-- End main_footer -->

				<div class="copyright"> <!-- Start copyright -->
					<div class="hmztop">Scroll To Top</div><!-- Back top -->
					<div class="footer_logo"><!-- Start footer logo -->
						<a href="#"><?php echo $sitename;?></a>
					</div><!-- End footer logo -->
					<div class="social_icon"><!--Start social_icon -->
						<span><a href="#"><i class="fa fa-facebook"></i></a></span>
						<span><a href="#"><i class="fa fa-twitter"></i></a></span>
					</div><!--End social_icon -->
					<p>Copyrights © 2015 All Rights Reserved by <a href="<?php echo $siteurl;?>"><?php echo $sitename;?></a></p>
				</div><!-- End copyright --> 
			</div><!-- End footer -->

		</div><!-- End row -->
	</div><!-- End all_content -->
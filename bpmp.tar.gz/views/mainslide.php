<div class="mian_slider clearfix"> 
					<div class="big_silder col-md-12"><!-- Start big silder -->
						<div class="row">
							<ul id="big-slid-post" class="a-post-box">
                                <?php
                            if(!empty($news)){
                            foreach($news as $n): ?>
								<li>
									<div class="feat-item img-section" data-bg-img="<?php echo Request::base_url()."/assets/upload/".$n->filename;?>">
									<div class="latest-overlay"></div>
										<div class="latest-txt">
											<span class="latest-cat"><a href="<?php echo Request::base_url()."/".Configuration::get("slugcat")."/".  str_replace(" ", "-", $n->category);?>"><?php echo $n->category;?></a></span>
											<h3 class="latest-title"><a rel="bookmark" href="<?php echo Request::base_url()."/".Configuration::get("slugpost")."/".$n->permalink;?>"><?php echo $n->title;?></a></h3>
											<div class="big-latest-content"> 
                                                <p ><?php echo substr($n->content, 0, 150);?></p>
											</div>

											<div class="hz_admin_pic"> 
                                                <img src="<?php echo Request::base_url();?>/assets/img/pic.jpg" width="40" height="40" class="img img-responsive" alt="Responsive image">
											</div>
											<span class="hz_post_by"><i class="fa fa-user"></i><a href="#">Admin</a></span>
											<span class="latest-meta">
												<span class="latest-date"><i class="fa fa-clock-o"></i> <?php echo $n->date;?></span>
											</span>
										</div>
									</div>
								</li>
                            <?php
                            endforeach;
                            }else{ ?>
                                <li>
									<div class="feat-item img-section" data-bg-img="img/news/mid-slider/5.jpg">
									<div class="latest-overlay"></div>
										<div class="latest-txt">
											<span class="latest-cat"><a href="">food</a></span>
											<h3 class="latest-title"><a data-dummy="fdfgdfgfg" href="single.html" rel="bookmark" title="#">There are many of Lorem Ipsum available</a></h3>
											<div class="big-latest-content">
												<p>Words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary,</p>
											</div>

											<div class="hz_admin_pic"> 
												<img src="<?php echo Request::base_url();?>/assets/img/demo/pic.jpg" class="img-responsive" alt="Responsive image">
											</div>
											<span class="hz_post_by"><i class="fa fa-user"></i><a href="#">Ashmawi Sami</a></span>
											<span class="latest-meta">
												<span class="latest-date"><i class="fa fa-clock-o"></i> Mar 10, 2015</span>
											</span>
										</div>
									</div>
								</li>
                            <?php } ?>
							</ul>
						</div>
					</div><!-- End big silder -->
				</div><!--End Mian slider -->
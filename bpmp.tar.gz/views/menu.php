<div class="nav_bar"><!-- Start nav_bar -->
							<nav id="primary_nav_wrap"><!-- Start primary_nav_wrap -->
								<ul>
                                    <li><a href="<?php echo Request::base_url();?>">Beranda</a></li>  
                                    <?php
                                    foreach ($nav as $nv): 
                                    $child= DBDriver::all("SELECT `id`, `title`, `permalink`, `publish` FROM `pages` WHERE `publish` = 1 AND `isparent`= ".$nv->id);
                                    if(empty($child)){ ?>
                                    <li>
                                        <a href="<?php echo Request::base_url()."/".Configuration::get("slugpage")."/".$nv->permalink;?>"><?php echo $nv->title;?></a>
                                    </li>                                    
                                    <?php } else{ ?>
                                    <li>
                                        <a href="#"><?php echo $nv->title;?></a>
                                        <ul>
                                            <?php foreach ($child as $ch): ?>
                                            <li><a href="<?php echo Request::base_url()."/".Configuration::get("slugpage")."/".$ch->permalink;?>"><?php echo $ch->title;?></a></li>
                                            <?php endforeach;?>
                                        </ul>
                                    </li>     
                                    <?php }  endforeach;?>							      
								</ul>
							</nav><!-- End primary_nav_wrap -->
						</div><!-- End nav_bar -->
						
						<div class="hz_responsive"><!--button for responsive menu-->
							<div id="dl-menu" class="dl-menuwrapper">
								<button class="dl-trigger">Open Menu</button>
							<ul class="dl-menu">
                                <li><a href="<?php echo Request::base_url();?>">Beranda</a></li>  
                                    <?php
                                    foreach ($nav as $nv): 
                                    $child= DBDriver::all("SELECT `id`, `title`, `permalink`, `publish` FROM `pages` WHERE `publish` = 1 AND `isparent`= ".$nv->id);
                                    if(empty($child)){ ?>
                                    <li>
                                        <a href="<?php echo Request::base_url()."/".Configuration::get("slugpage")."/".$nv->permalink;?>"><?php echo $nv->title;?></a>
                                    </li>                                    
                                    <?php } else{ ?>
                                    <li>
                                        <a href="<?php echo Request::base_url()."/".Configuration::get("slugpage")."/".$nv->permalink;?>"><?php echo $nv->title;?></a>
                                        <ul class="dl-submenu">
                                            <?php foreach ($child as $ch): ?>
                                            <li><a href="<?php echo Request::base_url()."/".Configuration::get("slugpage")."/".$ch->permalink;?>"><?php echo $ch->title;?></a></li>
                                            <?php endforeach;?>
                                        </ul>
                                    </li>     
                                    <?php }  endforeach;?>	
							</ul>
							</div><!-- /dl-menuwrapper -->
						</div><!--End button for responsive menu-->
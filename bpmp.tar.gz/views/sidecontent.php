
<div class="sidebar col-md-4"><!--Start Sidebar -->
						<div class="row">
							<div class="inner_sidebar"><!-- Start inner_sidebar -->

								<div class="widget  widget_about_me"><!-- Start widget About Me -->
									<div class="about_me">
										<div class="my_pic">
											<img src="<?php echo Request::base_url()."/assets/upload/".$themes_quote_image;?>" alt="">
										</div>
										<div class="my_name">
											<h4><?php echo $themes_quote_title1;?></h4>
										</div>
										<div class="my_words">
											<p><?php echo $themes_quote_content;?></p>
										</div>
										<div class="social_icon">
											<span><a href="#"><i class="fa fa-facebook"></i></a></span>
											<span><a href="#"><i class="fa fa-twitter"></i></a></span>
										</div>
									</div>
								</div><!-- End widget About Me -->

								<div class="widget widget_search"><!-- Start widget search -->
									<h4 class="widget_title">Search</h4>
									<form>
										<input type="search" value="Search here ..." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
										<input class="button" type="submit" value="Search Now">
									</form>
								</div><!-- End widget search -->

								<div class="widget widget_recent_post"><!-- Start widget recent post -->
									<h4 class="widget_title">Recent Post</h4>
									<ul class="recent_post">
                                        <?php
                                        if(empty($latestnews)){ ?>
                                        <div class="item">
                                            <p>No articles found</p>
                                        </div>
                                        <?php }
                                        else{ 
                                            foreach($latestnews as $ln):?>
                                        <li>
											<figure class="widget_post_thumbnail">
												<a href="#"><img src="<?php echo Request::base_url()."/assets/upload/".$ln->filename; ?>" height="80" width="80" alt="Image Not Found"></a>
											</figure>
											<div class="widget_post_info">
												<h5><a href="<?php echo Request::base_url()."/".Configuration::get("slugpost")."/".$ln->permalink;?>" style="color: #276197;"><?php echo $ln->title;?></a></h5>
                                                <p><?php echo substr($ln->content, 0, 150) ?></p>
												<div class="post_meta">
													<span class="date_meta"><a href="<?php echo Request::base_url()."/".Configuration::get("slugpost")."/".$ln->permalink;?>"><i class="fa fa-calendar"></i> <?php echo $ln->date;?></a></span>
												</div>
											</div>
										</li>
                                        <?php endforeach; } ?>
										
									</ul>
								</div><!-- End widget recent post 
								<div class="widget  widget_tag_cloud"><!-- Start widget tag cloud 
									<h4 class="widget_title">Tags</h4>
									<div class="tagcloud">
										<a href="#">audio</a>
										<a href="#">dailymotion</a>
										<a href="#">Gallery</a>
										<a href="#">LightBox</a>
										<a href="#">Link</a>
										<a href="#">mp3</a>
										<a href="#">nature</a>
										<a href="#">post</a>
										<a href="#">Quote</a>
										<a href="#">slider</a>
										<a href="#">soundcloud</a>
										<a href="#">sport</a>
										<a href="#">Standard</a>
										<a href="#">Twitter</a>
										<a href="#">vimeo</a>
									</div>
								</div><!-- End widget tag cloud -->
									
							</div><!-- End inner_sidebar -->
						</div>
					</div><!--End Sidebar -->